function velocity(xI, xF, t) {
    var total = ((xF - xI )/t);
    return total;
    }
    document.write(velocity(25,50,20)+"m/s");

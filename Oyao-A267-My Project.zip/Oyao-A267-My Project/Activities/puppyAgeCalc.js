function calculateDogAge(age) {
    var dogYears = 7*age;
    document.write("<br>"+"Your doggie is " + dogYears + " years old in dog years!");
}

calculateDogAge(1);
calculateDogAge(0.5);
calculateDogAge(12);